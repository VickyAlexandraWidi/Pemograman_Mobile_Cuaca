package com.vickyalexandrawidi.cuaca;

public class MainModel {
    private double temp_min;
    private double temp_max;

    public MainModel() {

    }

    public double getTemp_min() {
        return temp_min;
    }

    public void setTemp_min(double temp_min) {
        this.temp_min = temp_min;
    }

    public double getTemp_max() {
        return temp_max;
    }

    public void setTemp_max(double temp_max) {
        this.temp_max = temp_max;
    }
}
